<?php
/**
 * Bootstrap file to initiate core files.
 */
include 'core/pattern-category.php';
include 'core/template-functions.php';
